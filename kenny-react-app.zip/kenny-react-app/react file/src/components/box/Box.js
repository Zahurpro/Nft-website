import React from 'react'
import Button from '../button/Button'
import './Box.css'

const Box = (props) => {
   if(props.name === 'presale') {
    	return (
       <div className='box-container'>
          <h1 className='box-text'>Connect to Ethereum</h1>
          <Button name="Pre sale" ticket="793/1000" supply="1000" price="0.2" />
       </div>

      )
   } else {
      return (
         <div className='box-container'>
            <h1 className='box-text'>Connect to Ethereum</h1>
            <Button name="Public Sale" ticket="3256/3950" supply="3950" price="0.3" />
         </div>
  
      )
   }
}

export default Box
