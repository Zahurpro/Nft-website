import React from 'react'
import Buy from '../button/Buy'
import './Public.css'

const Public = (props) => {
  return (
    <div className='connect-container'>
       <div className='box-container height'>
          <div className='nft'>
            <img src={require('../images/nfts.jpeg')} alt='Logo Nfts' className='nft_img' />
          </div>
          <h1 className='text-1'>{props.name}</h1>
          <h3 className='text-2'>TICKETS : {props.tickets}</h3>
          <h3 className='text-3'>MY ADDRESS : 0x4DE96114D4722D80B5f3c980aAf2CC5a4b9d8aC4 </h3>
        </div>

        <div className='box-container height-1'>
            <h1 className='text-1'>Buy Your Tickets Here</h1>
            <ul className='list'>
                <li><b>Phase:</b> {props.name}</li>
                <li><b>Supply:</b> {props.supply}</li>
                <li><b>Phase Open:</b> 10 Feb 18:00 UTC - Until sold out</li>
                <li><b>Price:</b> {props.price}ETH + Gas fees</li>
            </ul>

            <p className='text-4'>You will be able to buy maximum of 10 tickets in this Phase. Price on Opensea is expected to be 0.6 ETH.</p>

            <h3 className='text-4'><b>Keep in mind:</b></h3>

            <p className='text-5'>🍀 2 Sloties are needed to breed a FREE Junior.</p>
            <p className='text-5'>👑 3 Sloties are needed to be eligible for DAO.</p>
            <p className='text-5'>💰 More Sloties you own, more shares from total income.</p>

            {/* <Buy /> */}
        </div>
    </div>
  )
}

export default Public
