import React from 'react';
import './Home.css';
import {
  Navbar,
  Header,
  Footer,
  Icons,
  Public,
  Box} from './components';




const Connected = () => {
 return (
    <main className='main'>
      <header className='header-bg'>
        <Navbar />
      </header> 
      <div className='box'>
        <Public />
      </div>
    </main>
  )
};

export default Connected
