import React from 'react';
import './App.css';
import {Routes, Route} from 'react-router-dom';
import Publicsale from './Publicsale';
import Presale from './Presale';
import Home from './Home';
import Connected from './Connected';



const App = () => {
 return (
    <div className='App'>
      <Routes>
        <Route path="" element={<Home />} />
        <Route path="presale" element={<Presale />} />
        <Route path="publicsale" element={<Publicsale />} />
        <Route path="public" element={<Connected />} />
      </Routes>
    </div>
   
  )
};

export default App;
