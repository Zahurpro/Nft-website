import React from 'react';
import './Home.css';
import {
  Navbar,
  Header,
  Footer,
  Icons,
  Welcome,
  Box} from './components';




const Home = () => {
 return (
    <main className='main'>
      <header className='header-bg'>
        <Navbar />
      </header> 
      <div className='box'>
        <Welcome />
      </div>
    </main>
  )
};

export default Home;
