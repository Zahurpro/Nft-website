import React from 'react'
import './Box.css'

const Welcome = () => {
  return (
    <div className='box-container'>
       <h1 className='box-text box-welcome'>Welcome to the Sloties NFT Official Sale. Please see the menu for the links to our Presales and Public sale.</h1> 
    </div>
  )
}

export default Welcome
