import React from 'react'
import './Navbar.css'
import { BsTwitter } from 'react-icons/bs'
import { SiDiscord } from 'react-icons/si'
import {Link} from 'react-router-dom'

const Navbar = () => {
  return (
    <nav className='nav-container'>
      <a href='#' className='nav-logo'>
        <img src={require('../images/Logo.png')} alt='Logo Nfts' className='nav-logo_img' />
        <div className='nav-logo_name'>Slotie</div>
      </a>

      <menu>
        <ul className='navigation'>
          <li><Link to='/presale' className='navigation-link'>Presale</Link></li>
          <li><Link to='/publicsale' className='navigation-link'>Public Sale</Link></li>
          <li>
            <a href='' className='navigation-icon'> 
              <BsTwitter size={24} color='#fff'/>
            </a>
          </li>

          <li>
            <a href='' className='navigation-icon'> 
              <SiDiscord  size={26} color='#fff'/>
            </a>
          </li>


        </ul>
      </menu>

    </nav>
  )
}

export default Navbar
