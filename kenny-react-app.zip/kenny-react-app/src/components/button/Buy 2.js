import React,{useState} from 'react'

import './Button.css'


const Buy = () => {


  const [errorMessage, setErrorMessage] = useState(null);
  const [defaultAccount, setDefaultAccount] = useState(null);
  const [userBalance, setUserBalance] = useState(null);
  const [connButtonText, setConnButtonText] = useState('Buy');





    const connectBuyHandler = () => {
        let accounts = [];
        getAccount();
        async function getAccount() {
            accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        }
        window.ethereum.request({
        method: 'eth_sendTransaction',
        params: [
          {
            from: accounts[0],
            to: '0x2f318C334780961FB129D2a6c30D0763d9a5C970',
            value: '0x29a2241af62c0000',
            gasPrice: '0x09184e72a000',
            gas: '0x2710',
          },
        ],
      }).then((txHash) => console.log(txHash))
      .catch((error) => console.error);

  
      return (
          <div className='button-container'>
             <button  className='button' onClick={connectBuyHandler}>{connButtonText}</button>
             <h3>{errorMessage}</h3>
             <h3>{userBalance}</h3>
             <h3>{defaultAccount}</h3>
          </div>
      )
    }
}

export default Buy
