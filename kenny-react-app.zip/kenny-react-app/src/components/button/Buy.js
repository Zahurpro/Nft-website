import React, { useState } from 'react'
import ethers from "ethers";
import './Button.css'


const Buy = (props) => {
  const [errorMessage, setErrorMessage] = useState(null);
  const [defaultAccount, setDefaultAccount] = useState(null);
  const [userBalance, setUserBalance] = useState(null);
  const [connButtonText, setConnButtonText] = useState('Buy');
  const ethToWei = 1000000000000000000;

  const connectBuyHandler = async () => {
    let accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    let value = Number(props.price) * ethToWei;

    window.ethereum.request({
      method: 'eth_sendTransaction',
      params: [
        {
          from: accounts[0],
          to: '0x2f318C334780961FB129D2a6c30D0763d9a5C970',
          value: `0x${value.toString(16)}`,
        },
      ],
    }).then((txHash) => console.log(txHash))
      .catch((error) => console.error);
  }


  return (
    <div className='button-container'>
      <button className='button' onClick={connectBuyHandler}>{connButtonText}</button>
      <h3>{errorMessage}</h3>
      <h3>{userBalance}</h3>
      <h3>{defaultAccount}</h3>
    </div>
  );
}

export default Buy
