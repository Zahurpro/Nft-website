import React,{useState} from 'react'
import {ethers} from 'ethers'
import './Button.css'
import swal from 'sweetalert'
import { useNavigate } from 'react-router-dom'

const Button = (props) => {
	const name = props.name;
  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState(null);
	const [defaultAccount, setDefaultAccount] = useState(null);
	const [userBalance, setUserBalance] = useState(null);
	const [connButtonText, setConnButtonText] = useState('Connect Wallet');


  const connectWalletHandler = () => {
		if (window.ethereum && window.ethereum.isMetaMask) {
			console.log('MetaMask Here!');

			window.ethereum.request({ method: 'eth_requestAccounts'})
			.then(result => {
			  navigate({pathname: props.path, state:{ name: name}});
				getAccountBalance(result[0]);
			})
			.catch(error => {
				setErrorMessage(error.message);
			
			});

		} else {
      swal({
        icon: 'error',
        title: 'Oops...',
        text: 'Metamask is not install!!!!',
        footer: '<a href="">Why do I have this issue?</a>'
      })
		}
	}

	// update account, will cause component re-render
	const accountChangedHandler = (newAccount) => {
		setDefaultAccount(newAccount);
		getAccountBalance(newAccount.toString());
	}

	const getAccountBalance = (account) => {
		window.ethereum.request({method: 'eth_getBalance', params: [account, 'latest']})
		.then(balance => {
			setUserBalance(ethers.utils.formatEther(balance));
		})
		.catch(error => {
			setErrorMessage(error.message);
		});
		
	};


	// listen for account changes
	// window.ethereum.on('accountsChanged', accountChangedHandler);

	// window.ethereum.on('chainChanged', chainChangedHandler);
  return (
    <div className='button-container'>
       <button  className='button' onClick={connectWalletHandler}>{connButtonText}</button>
       <h3>{errorMessage}</h3>
       <h3>{userBalance}</h3>
       <h3>{defaultAccount}</h3>
    </div>
  )
}

export default Button
