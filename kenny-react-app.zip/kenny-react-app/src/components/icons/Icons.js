import React from 'react'

const Icons = () => {
  return (
    <div>
      <h1>Icons</h1>
    </div>
  )
}

export default Icons
