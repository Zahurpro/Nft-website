import React from 'react';
import './Home.css';
import {
  Navbar,
  Header,
  Footer,
  Icons,
  Public,
  Box} from './components';




const Connected = (props) => {
 return (
    <main className='main'>
      <header className='header-bg'>
        <Navbar />
      </header> 
      <div className='box'>
        <Public price={props.price} />
      </div>
    </main>
  )
};

export default Connected
