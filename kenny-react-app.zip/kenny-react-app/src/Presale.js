import React from 'react';
import './Home.css';
import {
  Navbar,
  Header,
  Footer,
  Icons,
  Box} from './components';




const Presale = () => {
 return (
    <main className='main'>
      <header className='header-bg'>
        <Navbar />
      </header> 
      <div className='box'>
        <Box name="presale" />
      </div>
    </main>
  )
};

export default Presale
