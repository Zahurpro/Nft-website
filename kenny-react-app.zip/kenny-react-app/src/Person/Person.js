import React from 'react';
const person = (props) => {
    return (
        <div>
            <p>elhlhlo</p>
        </div>
    )
}

export default person;