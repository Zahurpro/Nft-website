import React from 'react';
import './Home.css';
import {
  Navbar,
  Header,
  Footer,
  Icons,
  Box} from './components';




const Publicsale = () => {
 return (
    <main className='main'>
      <header className='header-bg'>
        <Navbar />
      </header> 
      <div className='box'>
        <Box name="publicsale" />
      </div>
    </main>
  )
};

export default Publicsale
